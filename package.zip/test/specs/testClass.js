//import LoginPage from  '../pageobjects/login.page';
//import SecurePage from '../pageobjects/secure.page';

//describe('Test Application', function(){
  //  it('Enter Value in a field', function() {
    //    Browser.url('https://www.amazon.com/')

      //  await browser.url(`/`)
        //await new Promise(resolve => setTimeout(resolve, 5000));
        //const search = $('#twotabsearchtextbox');
        //search.setValue('Apple Mac Book');
        

    
//});

//});

